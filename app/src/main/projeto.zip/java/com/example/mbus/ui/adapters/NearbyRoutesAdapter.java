package com.example.mbus.ui.adapters;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.mbus.R;
import com.example.mbus.data.BusInfo;

import java.util.List;

public class NearbyRoutesAdapter extends RecyclerView.Adapter<NearbyRoutesAdapter.ViewHolder> {

    public interface OnBusClickListener {
        void onBusSelected(String busId); // <-- deve ser String
    }

    private final List<BusInfo> buses;
    private final OnBusClickListener listener;

    public NearbyRoutesAdapter(List<BusInfo> buses, OnBusClickListener listener) {
        this.buses = buses;
        this.listener = listener;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_listbuses, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        BusInfo bus = buses.get(position);
        holder.name.setText(bus.getRouteNumber() + " - " + bus.getRouteName());
        holder.description.setText("Companhia: " + bus.getCompanyName());

        holder.itemView.setOnClickListener(v -> {
            if (listener != null) {
                listener.onBusSelected(bus.getId()); // <-- aqui tem que ser o ID
            }
        });
    }

    @Override
    public int getItemCount() {
        return buses.size();
    }

    static class ViewHolder extends RecyclerView.ViewHolder {
        TextView name, description;

        ViewHolder(View itemView) {
            super(itemView);
            name = itemView.findViewById(R.id.schedule_name);
            description = itemView.findViewById(R.id.schedule_description);
        }
    }
}
