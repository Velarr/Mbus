package com.example.mbus.listeners;
public interface OnBusSelectedListener {
    void onBusSelected(String routeId);
}

