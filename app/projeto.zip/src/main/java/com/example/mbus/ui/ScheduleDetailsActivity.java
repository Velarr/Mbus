package com.example.mbus.ui;

import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.mbus.R;
import com.example.mbus.ui.adapters.ScheduleHourAdapter;
import com.google.firebase.firestore.FirebaseFirestore;

import java.text.SimpleDateFormat;
import java.util.*;

public class ScheduleDetailsActivity extends AppCompatActivity {

    private TextView txtRouteInfo;
    private RecyclerView recyclerView;
    private ScheduleHourAdapter adapter;
    private List<String> todayHours = new ArrayList<>();
    private FirebaseFirestore firestore;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_schedule_details);

        txtRouteInfo = findViewById(R.id.txt_route_info);
        recyclerView = findViewById(R.id.recycler_hours);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        adapter = new ScheduleHourAdapter(todayHours);
        recyclerView.setAdapter(adapter);

        firestore = FirebaseFirestore.getInstance();

        String routeId = getIntent().getStringExtra("routeId");
        String routeName = getIntent().getStringExtra("routeName");
        String routeNumber = getIntent().getStringExtra("routeNumber");
        String companyName = getIntent().getStringExtra("companyName");

        txtRouteInfo.setText(companyName + " - " + routeNumber + " " + routeName);

        if (routeId != null) {
            loadTodaySchedule(routeId);
        } else {
            Toast.makeText(this, "ID da rota não fornecido", Toast.LENGTH_SHORT).show();
        }
    }

    private void loadTodaySchedule(String routeId) {
        String dayType = getDayType();

        firestore.collection("routes")
                .document(routeId)
                .collection("schedules")
                .document(dayType)
                .get()
                .addOnSuccessListener(documentSnapshot -> {
                    if (documentSnapshot.exists()) {
                        List<String> times = (List<String>) documentSnapshot.get("times");
                        if (times != null) {
                            todayHours.clear();
                            todayHours.addAll(times);
                            sortHours(todayHours);
                            adapter.notifyDataSetChanged();
                        }
                    } else {
                        Toast.makeText(this, "Sem horários para hoje", Toast.LENGTH_SHORT).show();
                    }
                })
                .addOnFailureListener(e ->
                        Toast.makeText(this, "Erro ao carregar horários", Toast.LENGTH_SHORT).show());
    }

    private String getDayType() {
        Calendar calendar = Calendar.getInstance();
        int day = calendar.get(Calendar.DAY_OF_WEEK);
        if (day == Calendar.SATURDAY) return "saturday";
        else if (day == Calendar.SUNDAY) return "sunday";
        else return "weekday";
    }

    private void sortHours(List<String> list) {
        Collections.sort(list, (a, b) -> {
            try {
                SimpleDateFormat sdf = new SimpleDateFormat("HH:mm", Locale.getDefault());
                Date d1 = sdf.parse(a);
                Date d2 = sdf.parse(b);
                return d1.compareTo(d2);
            } catch (Exception e) {
                return a.compareTo(b);
            }
        });
    }
}
